<?php
$basefile = 'minvent.sqlite';// база данных 
