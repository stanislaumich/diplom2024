<?php
require('config.php');
echo file_get_contents('commonheader.tpl');
//---------------------------------------------------------------------------
echo '<h4> <center>Список ценностей</h4>';

$dbn = new PDO("sqlite:" . $basefile, '', '');
$sth = $dbn->prepare("select o.name name,o.dtend dt,c.num num from people p, oborud o, place c WHERE c.idpers=p.id and c.tip=1 and o.id=c.idoborud and p.id='" . $_POST['id'] . "';");
$sth->execute();
echo "<br><center><table border='1'>";
while ($r = $sth->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr><td>" . $r['name'] . "</td><td>" . $r['dt'] . "</td><td>" . $r['num'] . "</td></tr>";
}
echo "</table>";
//----------------------------------------------------------------------
echo "</center></body></html>";
