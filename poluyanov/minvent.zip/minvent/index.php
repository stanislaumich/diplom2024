<?php
require('config.php');
    echo file_get_contents('commonheader.tpl');
//---------------------------------------------------------------------------
    echo '<h4><center>Выберите сотрудника</h4>';

    $dbn = new PDO("sqlite:" . $basefile, '', '');
    //$sth->closeCursor();
    $sth = $dbn->prepare("SELECT id, name FROM people order by id ");
    $sth->execute();
echo "<center><form method=post action ='list.php'";
echo "<center>ФИО: <select name='id'><br>";
while ($r = $sth->fetch(PDO::FETCH_ASSOC)) {
    echo "<option value='" . $r['id'] . "'";
    echo ">" . $r['name'] . "</option><br>";

}
echo"</select><input type=submit value='Открыть'></form>";


//----------------------------------------------------------------------
    echo "</body></html>";



